Cases

Arrival rate < Service Rate

a. Arrival rate << Service rate